document.addEventListener('DOMContentLoaded', () => {

    // Terms & Conditions Checkbox logic
    const termsCheck = document.getElementById('termsAgree');
    const signupBtn = document.getElementById('signupBtn');
    
    if (termsCheck && signupBtn) {
        termsCheck.addEventListener('change', (e) => {
            signupBtn.disabled = !e.target.checked;
        });
    }

    // Universal File Upload & Preview Logic
    const fileInputs = document.querySelectorAll('input[type="file"]');
    
    fileInputs.forEach(input => {
        input.addEventListener('change', function() {
            const previewId = this.getAttribute('data-preview');
            const statusId = this.getAttribute('data-status');
            const previewImg = document.getElementById(previewId);
            const statusText = document.getElementById(statusId);
            const parentZone = this.parentElement;
            
            if (this.files && this.files[0]) {
                const file = this.files[0];

                const validTypes = ['image/jpeg', 'image/png', 'application/pdf'];
                if (!validTypes.includes(file.type)) {
                    alert("Invalid format. Please upload JPG, PNG, or PDF.");
                    this.value = '';
                    return;
                }

                if (file.type === 'application/pdf') {
                    if(previewImg) {
                        previewImg.style.display = 'none';
                        const p = parentZone.querySelector('p');
                        if(p) p.innerHTML = `<strong>📄 ${file.name}</strong>`;
                    }
                } else {
                    const reader = new FileReader();
                    reader.onload = (e) => {
                        if (previewImg) {
                            previewImg.src = e.target.result;
                            previewImg.style.display = 'block';
                            const siblings = parentZone.querySelectorAll('div, p');
                            siblings.forEach(el => el.style.opacity = '0'); 
                        }
                    };
                    reader.readAsDataURL(file);
                }

                if(statusText) {
                    statusText.innerHTML = `✅ ${file.name} attached`;
                    statusText.style.color = '#27ae60';
                }
            }
        });
    });
});

function handleLogin(e) {
    e.preventDefault();
    window.location.href = 'index.html';
}

function handleSignup(e) {
    e.preventDefault();
    const age = document.getElementById('userAge').value;
    if (age < 18) {
        alert("You must be at least 18 years old to register as a donor.");
        return;
    }
    window.location.href = 'verification.html';
}

function handleRecovery(e) {
    e.preventDefault();
    document.getElementById('recoveryForm').style.display = 'none';
    document.getElementById('successState').style.display = 'block';
}

function handleVerification(e) {
    e.preventDefault();
    // Show the custom pop-up instead of the browser alert
    document.getElementById('successModal').style.display = 'flex';
}

function closeModalAndRedirect() {
    // Hide the pop-up and redirect
    document.getElementById('successModal').style.display = 'none';
    window.location.href = 'index.html';
}

function loginAsRedCross() {
    const code = prompt("Enter Red Cross Access Code:");
    if (code) {
        alert("Institutional Access Granted.");
        window.location.href = 'index.html';
    }
}
